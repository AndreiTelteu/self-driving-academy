// BOTH immutable backend inventory required; no browser/native/build execution.
import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { verifyBuild, safePath } from './browser-store.mjs';
const manifest = process.argv[2],
  historical = process.argv.includes('--historical'),
  build = await verifyBuild(manifest, historical),
  entries = await readdir(build.captureRoot);
assert.equal(entries.length, 2, 'ExactlyBOTHbackendattempts; noignoredfailedsiblings');
const reports = [];
for (const id of entries) {
  assert(/^[0-9TZ]{10,40}$/.test(id));
  const folder = safePath(build.captureRoot, id),
    start = JSON.parse(await readFile(safePath(folder, 'started.json')));
  assert.equal(start.captureId, id);
  const stdout = execFileSync(
    process.execPath,
    [
      '--import',
      './scripts/register-typescript.mjs',
      'tests/browser/vehicle-recovery/verify-browser.mjs',
      manifest,
      folder,
      ...(historical ? ['--historical'] : []),
    ],
    { encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 },
  );
  const report = JSON.parse(stdout.trim());
  assert.equal(report.verification, 'PASS');
  reports.push(report);
}
assert.deepEqual(reports.map((r) => r.backend).sort(), ['WEBGL2', 'WEBGPU']);
assert(reports.every((r) => r.runs === 10 && r.comparisons === 580));
console.log(
  JSON.stringify({
    verification: 'PASS',
    mode: historical ? 'HISTORICAL_ARCHIVE' : 'CURRENT_BYTES',
    backends: reports.map((r) => r.backend),
    runs: 20,
    commonCheckpointComparisons: 1160,
    requiredAbsolute: reports.some((r) => r.requiredAbsolute === 'FAIL')
      ? 'FAIL'
      : reports.some((r) => r.requiredAbsolute === 'UNVALIDATED')
        ? 'UNVALIDATED'
        : 'PASS',
    optionalTiming: reports.some((r) => r.optionalTiming === 'FAIL')
      ? 'FAIL'
      : reports.every((r) => r.optionalTiming === 'NOT_MEASURED')
        ? 'NOT_MEASURED'
        : 'UNVALIDATED',
    overall: reports.some((r) => r.requiredAbsolute === 'FAIL' || r.optionalTiming === 'FAIL')
      ? 'FAIL'
      : 'UNVALIDATED',
    memory: reports.every((r) => r.memory === 'RAW_JS_PROXY_BASELINE_ONLY')
      ? 'RAW_JS_PROXY_BASELINE_ONLY'
      : 'UNVALIDATED',
    relative: 'AFTER_PENDING',
    scope: 'BOTH030hardwareBEFOREonly; not030Done/productionAFTER/Rfunctional',
  }),
);
